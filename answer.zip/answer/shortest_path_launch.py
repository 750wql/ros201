from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='shortest_path_package',
            executable='shortest_path_node',
            name='shortest_path_node',
            output='screen'
        )
    ])