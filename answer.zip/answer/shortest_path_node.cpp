#include <rclcpp/rclcpp.hpp>
#include <shortest_path_package/msg/overall_info.hpp>
#include <shortest_path_package/srv/shortest_path.hpp>
#include <vector>
#include <limits>
#include <queue>
#include <algorithm>

using namespace std::chrono_literals;

class ShortestPathNode : public rclcpp::Node
{
public:
    ShortestPathNode() : Node("shortest_path_node")
    {
        subscription_ = this->create_subscription<shortest_path_package::msg::OverallInfo>(
            "question", 10, std::bind(&ShortestPathNode::question_callback, this, std::placeholders::_1));

        client_ = this->create_client<shortest_path_package::srv::ShortestPath>("judger_server");
    }

private:
    void question_callback(const shortest_path_package::msg::OverallInfo::SharedPtr msg)
    {
        int num_cities = msg->number_of_cities;
        int num_roads = msg->number_of_roads;
        std::vector<std::vector<std::pair<int, int>>> graph(num_cities);

        for (const auto& road : msg->road_info)
        {
            graph[road.source].emplace_back(road.destination, road.length);
            graph[road.destination].emplace_back(road.source, road.length);
        }

        // 找到最短路径
        auto shortest_path = find_shortest_path(graph, 0, num_cities - 1);

        // 发送服务请求
        auto request = std::make_shared<shortest_path_package::srv::ShortestPath::Request>();
        request->path = shortest_path;

        while (!client_->wait_for_service(1s))
        {
            if (!rclcpp::ok())
            {
                RCLCPP_ERROR(this->get_logger(), "Interrupted while waiting for the service. Exiting.");
                return;
            }
            RCLCPP_INFO(this->get_logger(), "Service not available, waiting again...");
        }

        auto result_future = client_->async_send_request(request);
        if (rclcpp::spin_until_future_complete(this->get_node_base_interface(), result_future) == rclcpp::FutureReturnCode::SUCCESS)
        {
            auto result = result_future.get();
            RCLCPP_INFO(this->get_logger(), "Received score: %d", result->score);
        }
        else
        {
            RCLCPP_ERROR(this->get_logger(), "Failed to call service");
        }
    }

    std::vector<int> find_shortest_path(const std::vector<std::vector<std::pair<int, int>>>& graph, int start, int end)
    {
        int num_cities = graph.size();
        std::vector<int> dist(num_cities, std::numeric_limits<int>::max());
        std::vector<int> prev(num_cities, -1);
        std::vector<bool> visited(num_cities, false);
        dist[start] = 0;

        std::priority_queue<std::pair<int, int>, std::vector<std::pair<int, int>>, std::greater<std::pair<int, int>>> pq;
        pq.push({0, start});

        while (!pq.empty())
        {
            int u = pq.top().second;
            pq.pop();

            if (visited[u]) continue;
            visited[u] = true;

            if (u == end) break;

            for (const auto& neighbor : graph[u])
            {
                int v = neighbor.first;
                int weight = neighbor.second;

                if (!visited[v] && dist[u] + weight < dist[v])
                {
                    dist[v] = dist[u] + weight;
                    prev[v] = u;
                    pq.push({dist[v], v});
                }
            }
        }

        // 构建路径
        std::vector<int> path;
        for (int at = end; at!= -1; at = prev[at])
        {
            path.push_back(at);
        }
        std::reverse(path.begin(), path.end());
        return path;
    }

    rclcpp::Subscription<shortest_path_package::msg::OverallInfo>::SharedPtr subscription_;
    rclcpp::Client<shortest_path_package::srv::ShortestPath>::SharedPtr client_;
};
