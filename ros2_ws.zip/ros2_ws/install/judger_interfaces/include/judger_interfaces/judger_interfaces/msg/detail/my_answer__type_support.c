// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from judger_interfaces:msg/MyAnswer.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "judger_interfaces/msg/detail/my_answer__rosidl_typesupport_introspection_c.h"
#include "judger_interfaces/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "judger_interfaces/msg/detail/my_answer__functions.h"
#include "judger_interfaces/msg/detail/my_answer__struct.h"


// Include directives for member types
// Member `my_answer`
#include "rosidl_runtime_c/primitives_sequence_functions.h"

#ifdef __cplusplus
extern "C"
{
#endif

void judger_interfaces__msg__MyAnswer__rosidl_typesupport_introspection_c__MyAnswer_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  judger_interfaces__msg__MyAnswer__init(message_memory);
}

void judger_interfaces__msg__MyAnswer__rosidl_typesupport_introspection_c__MyAnswer_fini_function(void * message_memory)
{
  judger_interfaces__msg__MyAnswer__fini(message_memory);
}

size_t judger_interfaces__msg__MyAnswer__rosidl_typesupport_introspection_c__size_function__MyAnswer__my_answer(
  const void * untyped_member)
{
  const rosidl_runtime_c__int32__Sequence * member =
    (const rosidl_runtime_c__int32__Sequence *)(untyped_member);
  return member->size;
}

const void * judger_interfaces__msg__MyAnswer__rosidl_typesupport_introspection_c__get_const_function__MyAnswer__my_answer(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__int32__Sequence * member =
    (const rosidl_runtime_c__int32__Sequence *)(untyped_member);
  return &member->data[index];
}

void * judger_interfaces__msg__MyAnswer__rosidl_typesupport_introspection_c__get_function__MyAnswer__my_answer(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__int32__Sequence * member =
    (rosidl_runtime_c__int32__Sequence *)(untyped_member);
  return &member->data[index];
}

void judger_interfaces__msg__MyAnswer__rosidl_typesupport_introspection_c__fetch_function__MyAnswer__my_answer(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const int32_t * item =
    ((const int32_t *)
    judger_interfaces__msg__MyAnswer__rosidl_typesupport_introspection_c__get_const_function__MyAnswer__my_answer(untyped_member, index));
  int32_t * value =
    (int32_t *)(untyped_value);
  *value = *item;
}

void judger_interfaces__msg__MyAnswer__rosidl_typesupport_introspection_c__assign_function__MyAnswer__my_answer(
  void * untyped_member, size_t index, const void * untyped_value)
{
  int32_t * item =
    ((int32_t *)
    judger_interfaces__msg__MyAnswer__rosidl_typesupport_introspection_c__get_function__MyAnswer__my_answer(untyped_member, index));
  const int32_t * value =
    (const int32_t *)(untyped_value);
  *item = *value;
}

bool judger_interfaces__msg__MyAnswer__rosidl_typesupport_introspection_c__resize_function__MyAnswer__my_answer(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__int32__Sequence * member =
    (rosidl_runtime_c__int32__Sequence *)(untyped_member);
  rosidl_runtime_c__int32__Sequence__fini(member);
  return rosidl_runtime_c__int32__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember judger_interfaces__msg__MyAnswer__rosidl_typesupport_introspection_c__MyAnswer_message_member_array[1] = {
  {
    "my_answer",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(judger_interfaces__msg__MyAnswer, my_answer),  // bytes offset in struct
    NULL,  // default value
    judger_interfaces__msg__MyAnswer__rosidl_typesupport_introspection_c__size_function__MyAnswer__my_answer,  // size() function pointer
    judger_interfaces__msg__MyAnswer__rosidl_typesupport_introspection_c__get_const_function__MyAnswer__my_answer,  // get_const(index) function pointer
    judger_interfaces__msg__MyAnswer__rosidl_typesupport_introspection_c__get_function__MyAnswer__my_answer,  // get(index) function pointer
    judger_interfaces__msg__MyAnswer__rosidl_typesupport_introspection_c__fetch_function__MyAnswer__my_answer,  // fetch(index, &value) function pointer
    judger_interfaces__msg__MyAnswer__rosidl_typesupport_introspection_c__assign_function__MyAnswer__my_answer,  // assign(index, value) function pointer
    judger_interfaces__msg__MyAnswer__rosidl_typesupport_introspection_c__resize_function__MyAnswer__my_answer  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers judger_interfaces__msg__MyAnswer__rosidl_typesupport_introspection_c__MyAnswer_message_members = {
  "judger_interfaces__msg",  // message namespace
  "MyAnswer",  // message name
  1,  // number of fields
  sizeof(judger_interfaces__msg__MyAnswer),
  judger_interfaces__msg__MyAnswer__rosidl_typesupport_introspection_c__MyAnswer_message_member_array,  // message members
  judger_interfaces__msg__MyAnswer__rosidl_typesupport_introspection_c__MyAnswer_init_function,  // function to initialize message memory (memory has to be allocated)
  judger_interfaces__msg__MyAnswer__rosidl_typesupport_introspection_c__MyAnswer_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t judger_interfaces__msg__MyAnswer__rosidl_typesupport_introspection_c__MyAnswer_message_type_support_handle = {
  0,
  &judger_interfaces__msg__MyAnswer__rosidl_typesupport_introspection_c__MyAnswer_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_judger_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, judger_interfaces, msg, MyAnswer)() {
  if (!judger_interfaces__msg__MyAnswer__rosidl_typesupport_introspection_c__MyAnswer_message_type_support_handle.typesupport_identifier) {
    judger_interfaces__msg__MyAnswer__rosidl_typesupport_introspection_c__MyAnswer_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &judger_interfaces__msg__MyAnswer__rosidl_typesupport_introspection_c__MyAnswer_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
