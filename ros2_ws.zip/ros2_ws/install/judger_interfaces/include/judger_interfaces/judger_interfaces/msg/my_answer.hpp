// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef JUDGER_INTERFACES__MSG__MY_ANSWER_HPP_
#define JUDGER_INTERFACES__MSG__MY_ANSWER_HPP_

#include "judger_interfaces/msg/detail/my_answer__struct.hpp"
#include "judger_interfaces/msg/detail/my_answer__builder.hpp"
#include "judger_interfaces/msg/detail/my_answer__traits.hpp"
#include "judger_interfaces/msg/detail/my_answer__type_support.hpp"

#endif  // JUDGER_INTERFACES__MSG__MY_ANSWER_HPP_
