// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from judger_interfaces:msg/MyAnswer.idl
// generated code does not contain a copyright notice

#ifndef JUDGER_INTERFACES__MSG__DETAIL__MY_ANSWER__TRAITS_HPP_
#define JUDGER_INTERFACES__MSG__DETAIL__MY_ANSWER__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "judger_interfaces/msg/detail/my_answer__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace judger_interfaces
{

namespace msg
{

inline void to_flow_style_yaml(
  const MyAnswer & msg,
  std::ostream & out)
{
  out << "{";
  // member: my_answer
  {
    if (msg.my_answer.size() == 0) {
      out << "my_answer: []";
    } else {
      out << "my_answer: [";
      size_t pending_items = msg.my_answer.size();
      for (auto item : msg.my_answer) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const MyAnswer & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: my_answer
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.my_answer.size() == 0) {
      out << "my_answer: []\n";
    } else {
      out << "my_answer:\n";
      for (auto item : msg.my_answer) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const MyAnswer & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace judger_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use judger_interfaces::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const judger_interfaces::msg::MyAnswer & msg,
  std::ostream & out, size_t indentation = 0)
{
  judger_interfaces::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use judger_interfaces::msg::to_yaml() instead")]]
inline std::string to_yaml(const judger_interfaces::msg::MyAnswer & msg)
{
  return judger_interfaces::msg::to_yaml(msg);
}

template<>
inline const char * data_type<judger_interfaces::msg::MyAnswer>()
{
  return "judger_interfaces::msg::MyAnswer";
}

template<>
inline const char * name<judger_interfaces::msg::MyAnswer>()
{
  return "judger_interfaces/msg/MyAnswer";
}

template<>
struct has_fixed_size<judger_interfaces::msg::MyAnswer>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<judger_interfaces::msg::MyAnswer>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<judger_interfaces::msg::MyAnswer>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // JUDGER_INTERFACES__MSG__DETAIL__MY_ANSWER__TRAITS_HPP_
