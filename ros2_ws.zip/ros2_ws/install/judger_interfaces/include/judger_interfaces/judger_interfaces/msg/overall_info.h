// generated from rosidl_generator_c/resource/idl.h.em
// with input from judger_interfaces:msg/OverallInfo.idl
// generated code does not contain a copyright notice

#ifndef JUDGER_INTERFACES__MSG__OVERALL_INFO_H_
#define JUDGER_INTERFACES__MSG__OVERALL_INFO_H_

#include "judger_interfaces/msg/detail/overall_info__struct.h"
#include "judger_interfaces/msg/detail/overall_info__functions.h"
#include "judger_interfaces/msg/detail/overall_info__type_support.h"

#endif  // JUDGER_INTERFACES__MSG__OVERALL_INFO_H_
