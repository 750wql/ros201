// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from judger_interfaces:msg/RoadInfo.idl
// generated code does not contain a copyright notice

#ifndef JUDGER_INTERFACES__MSG__DETAIL__ROAD_INFO__BUILDER_HPP_
#define JUDGER_INTERFACES__MSG__DETAIL__ROAD_INFO__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "judger_interfaces/msg/detail/road_info__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace judger_interfaces
{

namespace msg
{

namespace builder
{

class Init_RoadInfo_length
{
public:
  explicit Init_RoadInfo_length(::judger_interfaces::msg::RoadInfo & msg)
  : msg_(msg)
  {}
  ::judger_interfaces::msg::RoadInfo length(::judger_interfaces::msg::RoadInfo::_length_type arg)
  {
    msg_.length = std::move(arg);
    return std::move(msg_);
  }

private:
  ::judger_interfaces::msg::RoadInfo msg_;
};

class Init_RoadInfo_destination
{
public:
  explicit Init_RoadInfo_destination(::judger_interfaces::msg::RoadInfo & msg)
  : msg_(msg)
  {}
  Init_RoadInfo_length destination(::judger_interfaces::msg::RoadInfo::_destination_type arg)
  {
    msg_.destination = std::move(arg);
    return Init_RoadInfo_length(msg_);
  }

private:
  ::judger_interfaces::msg::RoadInfo msg_;
};

class Init_RoadInfo_source
{
public:
  Init_RoadInfo_source()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RoadInfo_destination source(::judger_interfaces::msg::RoadInfo::_source_type arg)
  {
    msg_.source = std::move(arg);
    return Init_RoadInfo_destination(msg_);
  }

private:
  ::judger_interfaces::msg::RoadInfo msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::judger_interfaces::msg::RoadInfo>()
{
  return judger_interfaces::msg::builder::Init_RoadInfo_source();
}

}  // namespace judger_interfaces

#endif  // JUDGER_INTERFACES__MSG__DETAIL__ROAD_INFO__BUILDER_HPP_
