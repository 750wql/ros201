// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from judger_interfaces:msg/MyAnswer.idl
// generated code does not contain a copyright notice

#ifndef JUDGER_INTERFACES__MSG__DETAIL__MY_ANSWER__BUILDER_HPP_
#define JUDGER_INTERFACES__MSG__DETAIL__MY_ANSWER__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "judger_interfaces/msg/detail/my_answer__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace judger_interfaces
{

namespace msg
{

namespace builder
{

class Init_MyAnswer_my_answer
{
public:
  Init_MyAnswer_my_answer()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::judger_interfaces::msg::MyAnswer my_answer(::judger_interfaces::msg::MyAnswer::_my_answer_type arg)
  {
    msg_.my_answer = std::move(arg);
    return std::move(msg_);
  }

private:
  ::judger_interfaces::msg::MyAnswer msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::judger_interfaces::msg::MyAnswer>()
{
  return judger_interfaces::msg::builder::Init_MyAnswer_my_answer();
}

}  // namespace judger_interfaces

#endif  // JUDGER_INTERFACES__MSG__DETAIL__MY_ANSWER__BUILDER_HPP_
