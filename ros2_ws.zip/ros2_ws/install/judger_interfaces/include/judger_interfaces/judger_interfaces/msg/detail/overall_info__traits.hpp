// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from judger_interfaces:msg/OverallInfo.idl
// generated code does not contain a copyright notice

#ifndef JUDGER_INTERFACES__MSG__DETAIL__OVERALL_INFO__TRAITS_HPP_
#define JUDGER_INTERFACES__MSG__DETAIL__OVERALL_INFO__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "judger_interfaces/msg/detail/overall_info__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'infos'
#include "judger_interfaces/msg/detail/road_info__traits.hpp"

namespace judger_interfaces
{

namespace msg
{

inline void to_flow_style_yaml(
  const OverallInfo & msg,
  std::ostream & out)
{
  out << "{";
  // member: number_of_cities
  {
    out << "number_of_cities: ";
    rosidl_generator_traits::value_to_yaml(msg.number_of_cities, out);
    out << ", ";
  }

  // member: number_of_roads
  {
    out << "number_of_roads: ";
    rosidl_generator_traits::value_to_yaml(msg.number_of_roads, out);
    out << ", ";
  }

  // member: therehold
  {
    out << "therehold: ";
    rosidl_generator_traits::value_to_yaml(msg.therehold, out);
    out << ", ";
  }

  // member: infos
  {
    if (msg.infos.size() == 0) {
      out << "infos: []";
    } else {
      out << "infos: [";
      size_t pending_items = msg.infos.size();
      for (auto item : msg.infos) {
        to_flow_style_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: src_city
  {
    out << "src_city: ";
    rosidl_generator_traits::value_to_yaml(msg.src_city, out);
    out << ", ";
  }

  // member: des_city
  {
    out << "des_city: ";
    rosidl_generator_traits::value_to_yaml(msg.des_city, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const OverallInfo & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: number_of_cities
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "number_of_cities: ";
    rosidl_generator_traits::value_to_yaml(msg.number_of_cities, out);
    out << "\n";
  }

  // member: number_of_roads
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "number_of_roads: ";
    rosidl_generator_traits::value_to_yaml(msg.number_of_roads, out);
    out << "\n";
  }

  // member: therehold
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "therehold: ";
    rosidl_generator_traits::value_to_yaml(msg.therehold, out);
    out << "\n";
  }

  // member: infos
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.infos.size() == 0) {
      out << "infos: []\n";
    } else {
      out << "infos:\n";
      for (auto item : msg.infos) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_block_style_yaml(item, out, indentation + 2);
      }
    }
  }

  // member: src_city
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "src_city: ";
    rosidl_generator_traits::value_to_yaml(msg.src_city, out);
    out << "\n";
  }

  // member: des_city
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "des_city: ";
    rosidl_generator_traits::value_to_yaml(msg.des_city, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const OverallInfo & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace judger_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use judger_interfaces::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const judger_interfaces::msg::OverallInfo & msg,
  std::ostream & out, size_t indentation = 0)
{
  judger_interfaces::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use judger_interfaces::msg::to_yaml() instead")]]
inline std::string to_yaml(const judger_interfaces::msg::OverallInfo & msg)
{
  return judger_interfaces::msg::to_yaml(msg);
}

template<>
inline const char * data_type<judger_interfaces::msg::OverallInfo>()
{
  return "judger_interfaces::msg::OverallInfo";
}

template<>
inline const char * name<judger_interfaces::msg::OverallInfo>()
{
  return "judger_interfaces/msg/OverallInfo";
}

template<>
struct has_fixed_size<judger_interfaces::msg::OverallInfo>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<judger_interfaces::msg::OverallInfo>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<judger_interfaces::msg::OverallInfo>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // JUDGER_INTERFACES__MSG__DETAIL__OVERALL_INFO__TRAITS_HPP_
