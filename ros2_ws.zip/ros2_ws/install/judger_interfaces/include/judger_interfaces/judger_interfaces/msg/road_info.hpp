// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef JUDGER_INTERFACES__MSG__ROAD_INFO_HPP_
#define JUDGER_INTERFACES__MSG__ROAD_INFO_HPP_

#include "judger_interfaces/msg/detail/road_info__struct.hpp"
#include "judger_interfaces/msg/detail/road_info__builder.hpp"
#include "judger_interfaces/msg/detail/road_info__traits.hpp"
#include "judger_interfaces/msg/detail/road_info__type_support.hpp"

#endif  // JUDGER_INTERFACES__MSG__ROAD_INFO_HPP_
