// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from judger_interfaces:msg/OverallInfo.idl
// generated code does not contain a copyright notice
#include "judger_interfaces/msg/detail/overall_info__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `infos`
#include "judger_interfaces/msg/detail/road_info__functions.h"

bool
judger_interfaces__msg__OverallInfo__init(judger_interfaces__msg__OverallInfo * msg)
{
  if (!msg) {
    return false;
  }
  // number_of_cities
  // number_of_roads
  // therehold
  // infos
  if (!judger_interfaces__msg__RoadInfo__Sequence__init(&msg->infos, 0)) {
    judger_interfaces__msg__OverallInfo__fini(msg);
    return false;
  }
  // src_city
  // des_city
  return true;
}

void
judger_interfaces__msg__OverallInfo__fini(judger_interfaces__msg__OverallInfo * msg)
{
  if (!msg) {
    return;
  }
  // number_of_cities
  // number_of_roads
  // therehold
  // infos
  judger_interfaces__msg__RoadInfo__Sequence__fini(&msg->infos);
  // src_city
  // des_city
}

bool
judger_interfaces__msg__OverallInfo__are_equal(const judger_interfaces__msg__OverallInfo * lhs, const judger_interfaces__msg__OverallInfo * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // number_of_cities
  if (lhs->number_of_cities != rhs->number_of_cities) {
    return false;
  }
  // number_of_roads
  if (lhs->number_of_roads != rhs->number_of_roads) {
    return false;
  }
  // therehold
  if (lhs->therehold != rhs->therehold) {
    return false;
  }
  // infos
  if (!judger_interfaces__msg__RoadInfo__Sequence__are_equal(
      &(lhs->infos), &(rhs->infos)))
  {
    return false;
  }
  // src_city
  if (lhs->src_city != rhs->src_city) {
    return false;
  }
  // des_city
  if (lhs->des_city != rhs->des_city) {
    return false;
  }
  return true;
}

bool
judger_interfaces__msg__OverallInfo__copy(
  const judger_interfaces__msg__OverallInfo * input,
  judger_interfaces__msg__OverallInfo * output)
{
  if (!input || !output) {
    return false;
  }
  // number_of_cities
  output->number_of_cities = input->number_of_cities;
  // number_of_roads
  output->number_of_roads = input->number_of_roads;
  // therehold
  output->therehold = input->therehold;
  // infos
  if (!judger_interfaces__msg__RoadInfo__Sequence__copy(
      &(input->infos), &(output->infos)))
  {
    return false;
  }
  // src_city
  output->src_city = input->src_city;
  // des_city
  output->des_city = input->des_city;
  return true;
}

judger_interfaces__msg__OverallInfo *
judger_interfaces__msg__OverallInfo__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  judger_interfaces__msg__OverallInfo * msg = (judger_interfaces__msg__OverallInfo *)allocator.allocate(sizeof(judger_interfaces__msg__OverallInfo), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(judger_interfaces__msg__OverallInfo));
  bool success = judger_interfaces__msg__OverallInfo__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
judger_interfaces__msg__OverallInfo__destroy(judger_interfaces__msg__OverallInfo * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    judger_interfaces__msg__OverallInfo__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
judger_interfaces__msg__OverallInfo__Sequence__init(judger_interfaces__msg__OverallInfo__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  judger_interfaces__msg__OverallInfo * data = NULL;

  if (size) {
    data = (judger_interfaces__msg__OverallInfo *)allocator.zero_allocate(size, sizeof(judger_interfaces__msg__OverallInfo), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = judger_interfaces__msg__OverallInfo__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        judger_interfaces__msg__OverallInfo__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
judger_interfaces__msg__OverallInfo__Sequence__fini(judger_interfaces__msg__OverallInfo__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      judger_interfaces__msg__OverallInfo__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

judger_interfaces__msg__OverallInfo__Sequence *
judger_interfaces__msg__OverallInfo__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  judger_interfaces__msg__OverallInfo__Sequence * array = (judger_interfaces__msg__OverallInfo__Sequence *)allocator.allocate(sizeof(judger_interfaces__msg__OverallInfo__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = judger_interfaces__msg__OverallInfo__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
judger_interfaces__msg__OverallInfo__Sequence__destroy(judger_interfaces__msg__OverallInfo__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    judger_interfaces__msg__OverallInfo__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
judger_interfaces__msg__OverallInfo__Sequence__are_equal(const judger_interfaces__msg__OverallInfo__Sequence * lhs, const judger_interfaces__msg__OverallInfo__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!judger_interfaces__msg__OverallInfo__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
judger_interfaces__msg__OverallInfo__Sequence__copy(
  const judger_interfaces__msg__OverallInfo__Sequence * input,
  judger_interfaces__msg__OverallInfo__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(judger_interfaces__msg__OverallInfo);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    judger_interfaces__msg__OverallInfo * data =
      (judger_interfaces__msg__OverallInfo *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!judger_interfaces__msg__OverallInfo__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          judger_interfaces__msg__OverallInfo__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!judger_interfaces__msg__OverallInfo__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
