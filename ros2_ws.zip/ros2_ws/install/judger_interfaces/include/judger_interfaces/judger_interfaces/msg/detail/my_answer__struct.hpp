// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from judger_interfaces:msg/MyAnswer.idl
// generated code does not contain a copyright notice

#ifndef JUDGER_INTERFACES__MSG__DETAIL__MY_ANSWER__STRUCT_HPP_
#define JUDGER_INTERFACES__MSG__DETAIL__MY_ANSWER__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__judger_interfaces__msg__MyAnswer __attribute__((deprecated))
#else
# define DEPRECATED__judger_interfaces__msg__MyAnswer __declspec(deprecated)
#endif

namespace judger_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct MyAnswer_
{
  using Type = MyAnswer_<ContainerAllocator>;

  explicit MyAnswer_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_init;
  }

  explicit MyAnswer_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_init;
    (void)_alloc;
  }

  // field types and members
  using _my_answer_type =
    std::vector<int32_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<int32_t>>;
  _my_answer_type my_answer;

  // setters for named parameter idiom
  Type & set__my_answer(
    const std::vector<int32_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<int32_t>> & _arg)
  {
    this->my_answer = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    judger_interfaces::msg::MyAnswer_<ContainerAllocator> *;
  using ConstRawPtr =
    const judger_interfaces::msg::MyAnswer_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<judger_interfaces::msg::MyAnswer_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<judger_interfaces::msg::MyAnswer_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      judger_interfaces::msg::MyAnswer_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<judger_interfaces::msg::MyAnswer_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      judger_interfaces::msg::MyAnswer_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<judger_interfaces::msg::MyAnswer_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<judger_interfaces::msg::MyAnswer_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<judger_interfaces::msg::MyAnswer_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__judger_interfaces__msg__MyAnswer
    std::shared_ptr<judger_interfaces::msg::MyAnswer_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__judger_interfaces__msg__MyAnswer
    std::shared_ptr<judger_interfaces::msg::MyAnswer_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const MyAnswer_ & other) const
  {
    if (this->my_answer != other.my_answer) {
      return false;
    }
    return true;
  }
  bool operator!=(const MyAnswer_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct MyAnswer_

// alias to use template instance with default allocator
using MyAnswer =
  judger_interfaces::msg::MyAnswer_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace judger_interfaces

#endif  // JUDGER_INTERFACES__MSG__DETAIL__MY_ANSWER__STRUCT_HPP_
