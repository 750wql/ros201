﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from judger_interfaces:msg/MyAnswer.idl
// generated code does not contain a copyright notice

#ifndef JUDGER_INTERFACES__MSG__DETAIL__MY_ANSWER__STRUCT_H_
#define JUDGER_INTERFACES__MSG__DETAIL__MY_ANSWER__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'my_answer'
#include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in msg/MyAnswer in the package judger_interfaces.
/**
  * 存放得出的最短路径结果
 */
typedef struct judger_interfaces__msg__MyAnswer
{
  rosidl_runtime_c__int32__Sequence my_answer;
} judger_interfaces__msg__MyAnswer;

// Struct for a sequence of judger_interfaces__msg__MyAnswer.
typedef struct judger_interfaces__msg__MyAnswer__Sequence
{
  judger_interfaces__msg__MyAnswer * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} judger_interfaces__msg__MyAnswer__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // JUDGER_INTERFACES__MSG__DETAIL__MY_ANSWER__STRUCT_H_
