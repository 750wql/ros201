// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from judger_interfaces:srv/MyService.idl
// generated code does not contain a copyright notice

#ifndef JUDGER_INTERFACES__SRV__DETAIL__MY_SERVICE__STRUCT_H_
#define JUDGER_INTERFACES__SRV__DETAIL__MY_SERVICE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'answer'
#include "judger_interfaces/msg/detail/my_answer__struct.h"

/// Struct defined in srv/MyService in the package judger_interfaces.
typedef struct judger_interfaces__srv__MyService_Request
{
  judger_interfaces__msg__MyAnswer answer;
} judger_interfaces__srv__MyService_Request;

// Struct for a sequence of judger_interfaces__srv__MyService_Request.
typedef struct judger_interfaces__srv__MyService_Request__Sequence
{
  judger_interfaces__srv__MyService_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} judger_interfaces__srv__MyService_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'log'
#include "rosidl_runtime_c/string.h"

/// Struct defined in srv/MyService in the package judger_interfaces.
typedef struct judger_interfaces__srv__MyService_Response
{
  int8_t score;
  rosidl_runtime_c__String log;
} judger_interfaces__srv__MyService_Response;

// Struct for a sequence of judger_interfaces__srv__MyService_Response.
typedef struct judger_interfaces__srv__MyService_Response__Sequence
{
  judger_interfaces__srv__MyService_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} judger_interfaces__srv__MyService_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // JUDGER_INTERFACES__SRV__DETAIL__MY_SERVICE__STRUCT_H_
