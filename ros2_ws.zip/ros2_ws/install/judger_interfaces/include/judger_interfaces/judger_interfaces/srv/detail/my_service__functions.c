// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from judger_interfaces:srv/MyService.idl
// generated code does not contain a copyright notice
#include "judger_interfaces/srv/detail/my_service__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"

// Include directives for member types
// Member `answer`
#include "judger_interfaces/msg/detail/my_answer__functions.h"

bool
judger_interfaces__srv__MyService_Request__init(judger_interfaces__srv__MyService_Request * msg)
{
  if (!msg) {
    return false;
  }
  // answer
  if (!judger_interfaces__msg__MyAnswer__init(&msg->answer)) {
    judger_interfaces__srv__MyService_Request__fini(msg);
    return false;
  }
  return true;
}

void
judger_interfaces__srv__MyService_Request__fini(judger_interfaces__srv__MyService_Request * msg)
{
  if (!msg) {
    return;
  }
  // answer
  judger_interfaces__msg__MyAnswer__fini(&msg->answer);
}

bool
judger_interfaces__srv__MyService_Request__are_equal(const judger_interfaces__srv__MyService_Request * lhs, const judger_interfaces__srv__MyService_Request * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // answer
  if (!judger_interfaces__msg__MyAnswer__are_equal(
      &(lhs->answer), &(rhs->answer)))
  {
    return false;
  }
  return true;
}

bool
judger_interfaces__srv__MyService_Request__copy(
  const judger_interfaces__srv__MyService_Request * input,
  judger_interfaces__srv__MyService_Request * output)
{
  if (!input || !output) {
    return false;
  }
  // answer
  if (!judger_interfaces__msg__MyAnswer__copy(
      &(input->answer), &(output->answer)))
  {
    return false;
  }
  return true;
}

judger_interfaces__srv__MyService_Request *
judger_interfaces__srv__MyService_Request__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  judger_interfaces__srv__MyService_Request * msg = (judger_interfaces__srv__MyService_Request *)allocator.allocate(sizeof(judger_interfaces__srv__MyService_Request), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(judger_interfaces__srv__MyService_Request));
  bool success = judger_interfaces__srv__MyService_Request__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
judger_interfaces__srv__MyService_Request__destroy(judger_interfaces__srv__MyService_Request * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    judger_interfaces__srv__MyService_Request__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
judger_interfaces__srv__MyService_Request__Sequence__init(judger_interfaces__srv__MyService_Request__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  judger_interfaces__srv__MyService_Request * data = NULL;

  if (size) {
    data = (judger_interfaces__srv__MyService_Request *)allocator.zero_allocate(size, sizeof(judger_interfaces__srv__MyService_Request), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = judger_interfaces__srv__MyService_Request__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        judger_interfaces__srv__MyService_Request__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
judger_interfaces__srv__MyService_Request__Sequence__fini(judger_interfaces__srv__MyService_Request__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      judger_interfaces__srv__MyService_Request__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

judger_interfaces__srv__MyService_Request__Sequence *
judger_interfaces__srv__MyService_Request__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  judger_interfaces__srv__MyService_Request__Sequence * array = (judger_interfaces__srv__MyService_Request__Sequence *)allocator.allocate(sizeof(judger_interfaces__srv__MyService_Request__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = judger_interfaces__srv__MyService_Request__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
judger_interfaces__srv__MyService_Request__Sequence__destroy(judger_interfaces__srv__MyService_Request__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    judger_interfaces__srv__MyService_Request__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
judger_interfaces__srv__MyService_Request__Sequence__are_equal(const judger_interfaces__srv__MyService_Request__Sequence * lhs, const judger_interfaces__srv__MyService_Request__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!judger_interfaces__srv__MyService_Request__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
judger_interfaces__srv__MyService_Request__Sequence__copy(
  const judger_interfaces__srv__MyService_Request__Sequence * input,
  judger_interfaces__srv__MyService_Request__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(judger_interfaces__srv__MyService_Request);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    judger_interfaces__srv__MyService_Request * data =
      (judger_interfaces__srv__MyService_Request *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!judger_interfaces__srv__MyService_Request__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          judger_interfaces__srv__MyService_Request__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!judger_interfaces__srv__MyService_Request__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}


// Include directives for member types
// Member `log`
#include "rosidl_runtime_c/string_functions.h"

bool
judger_interfaces__srv__MyService_Response__init(judger_interfaces__srv__MyService_Response * msg)
{
  if (!msg) {
    return false;
  }
  // score
  // log
  if (!rosidl_runtime_c__String__init(&msg->log)) {
    judger_interfaces__srv__MyService_Response__fini(msg);
    return false;
  }
  return true;
}

void
judger_interfaces__srv__MyService_Response__fini(judger_interfaces__srv__MyService_Response * msg)
{
  if (!msg) {
    return;
  }
  // score
  // log
  rosidl_runtime_c__String__fini(&msg->log);
}

bool
judger_interfaces__srv__MyService_Response__are_equal(const judger_interfaces__srv__MyService_Response * lhs, const judger_interfaces__srv__MyService_Response * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // score
  if (lhs->score != rhs->score) {
    return false;
  }
  // log
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->log), &(rhs->log)))
  {
    return false;
  }
  return true;
}

bool
judger_interfaces__srv__MyService_Response__copy(
  const judger_interfaces__srv__MyService_Response * input,
  judger_interfaces__srv__MyService_Response * output)
{
  if (!input || !output) {
    return false;
  }
  // score
  output->score = input->score;
  // log
  if (!rosidl_runtime_c__String__copy(
      &(input->log), &(output->log)))
  {
    return false;
  }
  return true;
}

judger_interfaces__srv__MyService_Response *
judger_interfaces__srv__MyService_Response__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  judger_interfaces__srv__MyService_Response * msg = (judger_interfaces__srv__MyService_Response *)allocator.allocate(sizeof(judger_interfaces__srv__MyService_Response), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(judger_interfaces__srv__MyService_Response));
  bool success = judger_interfaces__srv__MyService_Response__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
judger_interfaces__srv__MyService_Response__destroy(judger_interfaces__srv__MyService_Response * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    judger_interfaces__srv__MyService_Response__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
judger_interfaces__srv__MyService_Response__Sequence__init(judger_interfaces__srv__MyService_Response__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  judger_interfaces__srv__MyService_Response * data = NULL;

  if (size) {
    data = (judger_interfaces__srv__MyService_Response *)allocator.zero_allocate(size, sizeof(judger_interfaces__srv__MyService_Response), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = judger_interfaces__srv__MyService_Response__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        judger_interfaces__srv__MyService_Response__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
judger_interfaces__srv__MyService_Response__Sequence__fini(judger_interfaces__srv__MyService_Response__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      judger_interfaces__srv__MyService_Response__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

judger_interfaces__srv__MyService_Response__Sequence *
judger_interfaces__srv__MyService_Response__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  judger_interfaces__srv__MyService_Response__Sequence * array = (judger_interfaces__srv__MyService_Response__Sequence *)allocator.allocate(sizeof(judger_interfaces__srv__MyService_Response__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = judger_interfaces__srv__MyService_Response__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
judger_interfaces__srv__MyService_Response__Sequence__destroy(judger_interfaces__srv__MyService_Response__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    judger_interfaces__srv__MyService_Response__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
judger_interfaces__srv__MyService_Response__Sequence__are_equal(const judger_interfaces__srv__MyService_Response__Sequence * lhs, const judger_interfaces__srv__MyService_Response__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!judger_interfaces__srv__MyService_Response__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
judger_interfaces__srv__MyService_Response__Sequence__copy(
  const judger_interfaces__srv__MyService_Response__Sequence * input,
  judger_interfaces__srv__MyService_Response__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(judger_interfaces__srv__MyService_Response);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    judger_interfaces__srv__MyService_Response * data =
      (judger_interfaces__srv__MyService_Response *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!judger_interfaces__srv__MyService_Response__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          judger_interfaces__srv__MyService_Response__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!judger_interfaces__srv__MyService_Response__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
