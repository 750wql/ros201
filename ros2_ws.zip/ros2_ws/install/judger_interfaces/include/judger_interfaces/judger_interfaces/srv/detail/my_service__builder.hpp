// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from judger_interfaces:srv/MyService.idl
// generated code does not contain a copyright notice

#ifndef JUDGER_INTERFACES__SRV__DETAIL__MY_SERVICE__BUILDER_HPP_
#define JUDGER_INTERFACES__SRV__DETAIL__MY_SERVICE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "judger_interfaces/srv/detail/my_service__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace judger_interfaces
{

namespace srv
{

namespace builder
{

class Init_MyService_Request_answer
{
public:
  Init_MyService_Request_answer()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::judger_interfaces::srv::MyService_Request answer(::judger_interfaces::srv::MyService_Request::_answer_type arg)
  {
    msg_.answer = std::move(arg);
    return std::move(msg_);
  }

private:
  ::judger_interfaces::srv::MyService_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::judger_interfaces::srv::MyService_Request>()
{
  return judger_interfaces::srv::builder::Init_MyService_Request_answer();
}

}  // namespace judger_interfaces


namespace judger_interfaces
{

namespace srv
{

namespace builder
{

class Init_MyService_Response_log
{
public:
  explicit Init_MyService_Response_log(::judger_interfaces::srv::MyService_Response & msg)
  : msg_(msg)
  {}
  ::judger_interfaces::srv::MyService_Response log(::judger_interfaces::srv::MyService_Response::_log_type arg)
  {
    msg_.log = std::move(arg);
    return std::move(msg_);
  }

private:
  ::judger_interfaces::srv::MyService_Response msg_;
};

class Init_MyService_Response_score
{
public:
  Init_MyService_Response_score()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MyService_Response_log score(::judger_interfaces::srv::MyService_Response::_score_type arg)
  {
    msg_.score = std::move(arg);
    return Init_MyService_Response_log(msg_);
  }

private:
  ::judger_interfaces::srv::MyService_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::judger_interfaces::srv::MyService_Response>()
{
  return judger_interfaces::srv::builder::Init_MyService_Response_score();
}

}  // namespace judger_interfaces

#endif  // JUDGER_INTERFACES__SRV__DETAIL__MY_SERVICE__BUILDER_HPP_
