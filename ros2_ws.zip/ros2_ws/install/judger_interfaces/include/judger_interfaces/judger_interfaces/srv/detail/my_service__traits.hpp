// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from judger_interfaces:srv/MyService.idl
// generated code does not contain a copyright notice

#ifndef JUDGER_INTERFACES__SRV__DETAIL__MY_SERVICE__TRAITS_HPP_
#define JUDGER_INTERFACES__SRV__DETAIL__MY_SERVICE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "judger_interfaces/srv/detail/my_service__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'answer'
#include "judger_interfaces/msg/detail/my_answer__traits.hpp"

namespace judger_interfaces
{

namespace srv
{

inline void to_flow_style_yaml(
  const MyService_Request & msg,
  std::ostream & out)
{
  out << "{";
  // member: answer
  {
    out << "answer: ";
    to_flow_style_yaml(msg.answer, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const MyService_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: answer
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "answer:\n";
    to_block_style_yaml(msg.answer, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const MyService_Request & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace judger_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use judger_interfaces::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const judger_interfaces::srv::MyService_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  judger_interfaces::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use judger_interfaces::srv::to_yaml() instead")]]
inline std::string to_yaml(const judger_interfaces::srv::MyService_Request & msg)
{
  return judger_interfaces::srv::to_yaml(msg);
}

template<>
inline const char * data_type<judger_interfaces::srv::MyService_Request>()
{
  return "judger_interfaces::srv::MyService_Request";
}

template<>
inline const char * name<judger_interfaces::srv::MyService_Request>()
{
  return "judger_interfaces/srv/MyService_Request";
}

template<>
struct has_fixed_size<judger_interfaces::srv::MyService_Request>
  : std::integral_constant<bool, has_fixed_size<judger_interfaces::msg::MyAnswer>::value> {};

template<>
struct has_bounded_size<judger_interfaces::srv::MyService_Request>
  : std::integral_constant<bool, has_bounded_size<judger_interfaces::msg::MyAnswer>::value> {};

template<>
struct is_message<judger_interfaces::srv::MyService_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace judger_interfaces
{

namespace srv
{

inline void to_flow_style_yaml(
  const MyService_Response & msg,
  std::ostream & out)
{
  out << "{";
  // member: score
  {
    out << "score: ";
    rosidl_generator_traits::value_to_yaml(msg.score, out);
    out << ", ";
  }

  // member: log
  {
    out << "log: ";
    rosidl_generator_traits::value_to_yaml(msg.log, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const MyService_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: score
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "score: ";
    rosidl_generator_traits::value_to_yaml(msg.score, out);
    out << "\n";
  }

  // member: log
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "log: ";
    rosidl_generator_traits::value_to_yaml(msg.log, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const MyService_Response & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace judger_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use judger_interfaces::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const judger_interfaces::srv::MyService_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  judger_interfaces::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use judger_interfaces::srv::to_yaml() instead")]]
inline std::string to_yaml(const judger_interfaces::srv::MyService_Response & msg)
{
  return judger_interfaces::srv::to_yaml(msg);
}

template<>
inline const char * data_type<judger_interfaces::srv::MyService_Response>()
{
  return "judger_interfaces::srv::MyService_Response";
}

template<>
inline const char * name<judger_interfaces::srv::MyService_Response>()
{
  return "judger_interfaces/srv/MyService_Response";
}

template<>
struct has_fixed_size<judger_interfaces::srv::MyService_Response>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<judger_interfaces::srv::MyService_Response>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<judger_interfaces::srv::MyService_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<judger_interfaces::srv::MyService>()
{
  return "judger_interfaces::srv::MyService";
}

template<>
inline const char * name<judger_interfaces::srv::MyService>()
{
  return "judger_interfaces/srv/MyService";
}

template<>
struct has_fixed_size<judger_interfaces::srv::MyService>
  : std::integral_constant<
    bool,
    has_fixed_size<judger_interfaces::srv::MyService_Request>::value &&
    has_fixed_size<judger_interfaces::srv::MyService_Response>::value
  >
{
};

template<>
struct has_bounded_size<judger_interfaces::srv::MyService>
  : std::integral_constant<
    bool,
    has_bounded_size<judger_interfaces::srv::MyService_Request>::value &&
    has_bounded_size<judger_interfaces::srv::MyService_Response>::value
  >
{
};

template<>
struct is_service<judger_interfaces::srv::MyService>
  : std::true_type
{
};

template<>
struct is_service_request<judger_interfaces::srv::MyService_Request>
  : std::true_type
{
};

template<>
struct is_service_response<judger_interfaces::srv::MyService_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

#endif  // JUDGER_INTERFACES__SRV__DETAIL__MY_SERVICE__TRAITS_HPP_
