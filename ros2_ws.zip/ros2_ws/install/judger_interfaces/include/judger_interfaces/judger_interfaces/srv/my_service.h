// generated from rosidl_generator_c/resource/idl.h.em
// with input from judger_interfaces:srv/MyService.idl
// generated code does not contain a copyright notice

#ifndef JUDGER_INTERFACES__SRV__MY_SERVICE_H_
#define JUDGER_INTERFACES__SRV__MY_SERVICE_H_

#include "judger_interfaces/srv/detail/my_service__struct.h"
#include "judger_interfaces/srv/detail/my_service__functions.h"
#include "judger_interfaces/srv/detail/my_service__type_support.h"

#endif  // JUDGER_INTERFACES__SRV__MY_SERVICE_H_
