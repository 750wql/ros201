// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef JUDGER_INTERFACES__SRV__MY_SERVICE_HPP_
#define JUDGER_INTERFACES__SRV__MY_SERVICE_HPP_

#include "judger_interfaces/srv/detail/my_service__struct.hpp"
#include "judger_interfaces/srv/detail/my_service__builder.hpp"
#include "judger_interfaces/srv/detail/my_service__traits.hpp"
#include "judger_interfaces/srv/detail/my_service__type_support.hpp"

#endif  // JUDGER_INTERFACES__SRV__MY_SERVICE_HPP_
